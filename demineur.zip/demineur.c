#include <stdlib.h>
#include <time.h>
#include "inout.h"

#define MAX_LIGNES 30
#define MAX_COLS 30

#define CACHE 0
#define OUVERT 1
#define DRAPEAU 2

#define VRAI 1
#define FAUX 0

// Indices pour le tableau de configuration
#define IDX_TAILLE 0
#define IDX_DIFF 1

//  Fonctions Utilitaires

int est_dans_grille(int r, int c, int max_r, int max_c) {
    if (r >= 0 && r < max_r && c >= 0 && c < max_c) {
        return VRAI;
    }
    return FAUX;
}

// Fonction d'affichage
void afficher_plateau(int cellules[MAX_LIGNES][MAX_COLS], int etats[MAX_LIGNES][MAX_COLS], int lignes, int colonnes, int tout_reveler) {
    int r;
    int c;

    ecrireSautDeLigne();
    ecrireString("    ");
    for (c = 0; c < colonnes; c++) {
        ecrireInt(c + 1);
        ecrireString(" ");
    }
    ecrireSautDeLigne();

    ecrireString("   ");
    for (c = 0; c < colonnes; c++) { ecrireString("--"); }
    ecrireSautDeLigne();

    for (r = 0; r < lignes; r++) {
        ecrireInt(r + 1);
        ecrireString("| ");

        for (c = 0; c < colonnes; c++) {
            int a_afficher = 0;

            if (tout_reveler == VRAI) {
                a_afficher = 1;
            } else {
                if (etats[r][c] == OUVERT) a_afficher = 1;
                else if (etats[r][c] == DRAPEAU) a_afficher = 2;
                else a_afficher = 0;
            }

            if (a_afficher == 0) ecrireString(". ");
            else if (a_afficher == 2) ecrireString("F ");
            else {
                if (cellules[r][c] == -1) ecrireString("* ");
                else if (cellules[r][c] == 0) ecrireString("  ");
                else {
                    ecrireInt(cellules[r][c]);
                    ecrireString(" ");
                }
            }
        }
        ecrireSautDeLigne();
    }
}

// Calcul des chiffres
void calculer_voisins(int cellules[MAX_LIGNES][MAX_COLS], int lignes, int colonnes) {
    int r;
    int c;
    for (r = 0; r < lignes; r++) {
        for (c = 0; c < colonnes; c++) {
            if (cellules[r][c] == -1) continue;

            int count = 0;
            int dr;
            int dc;
            for (dr = -1; dr <= 1; dr++) {
                for (dc = -1; dc <= 1; dc++) {
                    if (dr == 0 && dc == 0) continue;
                    if (est_dans_grille(r + dr, c + dc, lignes, colonnes) == VRAI) {
                        if (cellules[r + dr][c + dc] == -1) {
                            count = count + 1;
                        }
                    }
                }
            }
            cellules[r][c] = count;
        }
    }
}

void placer_mines(int cellules[MAX_LIGNES][MAX_COLS], int lignes, int colonnes, int nb_mines, int avoid_r, int avoid_c) {
    int placees = 0;
    while (placees < nb_mines) {
        int r = rand() % lignes;
        int c = rand() % colonnes;

        if (abs(r - avoid_r) <= 1 && abs(c - avoid_c) <= 1) continue;

        if (cellules[r][c] != -1) {
            cellules[r][c] = -1;
            placees = placees + 1;
        }
    }
}

// Propagation récursive
int propagation_vide(int cellules[MAX_LIGNES][MAX_COLS], int etats[MAX_LIGNES][MAX_COLS], int r, int c, int lignes, int colonnes) {
    if (est_dans_grille(r, c, lignes, colonnes) == FAUX) return 0;
    if (etats[r][c] == OUVERT) return 0;
    if (etats[r][c] == DRAPEAU) return 0;

    etats[r][c] = OUVERT;
    int total_ouvert = 1; // On vient d'ouvrir 1 case

    if (cellules[r][c] == 0) {
        int dr;
        int dc;
        for (dr = -1; dr <= 1; dr++) {
            for (dc = -1; dc <= 1; dc++) {
                total_ouvert = total_ouvert + propagation_vide(cellules, etats, r + dr, c + dc, lignes, colonnes);
            }
        }
    }
    return total_ouvert;
}

// Procédure de Jeu
void jouer_partie(int lignes, int colonnes, int mines) {
    int cellules[MAX_LIGNES][MAX_COLS];
    int etats[MAX_LIGNES][MAX_COLS];

    int i;
    int j;
    for(i=0; i<lignes; i++) {
        for(j=0; j<colonnes; j++) {
            cellules[i][j] = 0;
            etats[i][j] = CACHE;
        }
    }

    int cases_ouvertes = 0;
    int premier_coup = VRAI;
    int perdu = FAUX;
    int gagne = FAUX;

    while (perdu == FAUX && gagne == FAUX) {
        afficher_plateau(cellules, etats, lignes, colonnes, FAUX);

        ecrireString("Action (1=Ouvrir, 2=Drapeau, 0=Quitter) : ");
        int action = lireInt();

        if (action == 0) return;

        ecrireString("Ligne : ");
        int r = lireInt() - 1;
        ecrireString("Colonne : ");
        int c = lireInt() - 1;

        if (est_dans_grille(r, c, lignes, colonnes) == FAUX) {
            ecrireString("Hors limites !\n");
            continue;
        }

        if (action == 2) {
            if (etats[r][c] == CACHE) etats[r][c] = DRAPEAU;
            else if (etats[r][c] == DRAPEAU) etats[r][c] = CACHE;
        }
        else if (action == 1) {
            if (etats[r][c] == DRAPEAU || etats[r][c] == OUVERT) continue;

            if (premier_coup == VRAI) {
                placer_mines(cellules, lignes, colonnes, mines, r, c);
                calculer_voisins(cellules, lignes, colonnes);
                premier_coup = FAUX;
            }

            if (cellules[r][c] == -1) {
                perdu = VRAI;
            } else {
                // On récupère le nombre de cases ouvertes par la fonction et on l'ajoute
                cases_ouvertes = cases_ouvertes + propagation_vide(cellules, etats, r, c, lignes, colonnes);
            }
        }

        if ((lignes * colonnes) - cases_ouvertes == mines) {
            gagne = VRAI;
        }
    }

    afficher_plateau(cellules, etats, lignes, colonnes, VRAI);
    if (gagne == VRAI) ecrireString("\nVICTOIRE !\n");
    else ecrireString("\nBOOM ! PERDU.\n");

    ecrireString("Tapez 1 pour continuer...");
    lireInt();
}

// GESTION DES OPTIONS AVEC TABLEAU
// On passe un tableau car le tableau est passé par référence.
// config[0] = taille, config[1] = difficulté
void gerer_options(int config[]) {
    int choix = 0;
    while (choix != 3) {
        ecrireSautDeLigne();
        ecrireString("--- OPTIONS ---"); ecrireSautDeLigne();

        ecrireString("Taille actuelle : ");
        if(config[IDX_TAILLE] == 1) ecrireString("9x9"); else ecrireString("16x16");
        ecrireSautDeLigne();

        ecrireString("Difficulte actuelle : ");
        if(config[IDX_DIFF] == 1) ecrireString("Normale"); else ecrireString("Difficile");
        ecrireSautDeLigne();

        ecrireString("1. Changer taille"); ecrireSautDeLigne();
        ecrireString("2. Changer difficulte"); ecrireSautDeLigne();
        ecrireString("3. Retour"); ecrireSautDeLigne();

        ecrireString("Choix : ");
        choix = lireInt();

        if (choix == 1) {
            ecrireString("Taille (1=Petit, 2=Grand) : ");
            int t = lireInt();
            if (t == 1 || t == 2) {
                config[IDX_TAILLE] = t; // Modifie directement le tableau du main
            }
        } else if (choix == 2) {
            ecrireString("Difficulte (1=Normal, 2=Dur) : ");
            int d = lireInt();
            if (d == 1 || d == 2) {
                config[IDX_DIFF] = d; // Modifie directement le tableau du main
            }
        }
    }
}

int main() {
    srand(time(NULL));

    // Tableau de configuration pour simuler le passage par référence
    // config[0] -> choix_taille
    // config[1] -> choix_diff
    int config[2];
    config[IDX_TAILLE] = 1;
    config[IDX_DIFF] = 1;

    int quitter = FAUX;

    while (quitter == FAUX) {
        ecrireSautDeLigne();
        ecrireString("=== MENU ==="); ecrireSautDeLigne();
        ecrireString("1. Jouer"); ecrireSautDeLigne();
        ecrireString("2. Options"); ecrireSautDeLigne();
        ecrireString("3. Quitter"); ecrireSautDeLigne();

        ecrireString("Votre choix : ");
        int menu = lireInt();

        if (menu == 1) {
            int l, c, m;

            // Lecture depuis le tableau de configuration
            if (config[IDX_TAILLE] == 1) { l = 9; c = 9; }
            else { l = 16; c = 16; }

            if (config[IDX_DIFF] == 1) {
                if(config[IDX_TAILLE]==1) m=10; else m=40;
            } else {
                if(config[IDX_TAILLE]==1) m=20; else m=80;
            }

            jouer_partie(l, c, m);
        }
        else if (menu == 2) {
            // On passe le tableau 'config'.
            // cela permet à la fonction de modifier le contenu du tableau.
            gerer_options(config);
        }
        else if (menu == 3) {
            quitter = VRAI;
        }
    }

    ecrireString("Au revoir.");
    return 0;
}